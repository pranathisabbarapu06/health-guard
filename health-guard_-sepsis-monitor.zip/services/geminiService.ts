import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, RiskLevel } from "../types";

const SYSTEM_INSTRUCTION = `
You are "Health Guard v2", a Bio-Adaptive Medical AI. 
Your goal is to detect Sepsis by fusing Vitals, Visual Cues, Environmental Factors, and Behavioral Signals.

INPUTS:
1. Vitals Window (HR, Temp, BP, SpO2).
2. Environmental Data (Room Temp, Humidity).
3. Behavioral Data (Activity Level).
4. Visual Snapshot (IV Site).

LOGIC & CORRELATION RULES:
1. CONTEXT AWARENESS: 
   - High HR + High Activity = Normal (Exercise/Movement).
   - High HR + Low Activity + High Temp = WARNING (Infection).
   - High Temp + High Room Temp = Check Environment first.
   - High Temp + Low Room Temp = Internal Fever (High Risk).
   
2. SEPSIS INDICATORS (The "Sepsis 6" Protocol):
   - Hypotension (Low BP).
   - Tachycardia (High HR) > 90 bpm.
   - Fever > 101F OR Hypothermia < 96.8F.
   - Visual: Redness/Edema at IV site.

3. CLOSED LOOP ACTION:
   - Suggest a clinical intervention based on the state.
   - Examples: "Check IV Line", "Administer Fluids", "Apply Cooling", "Urgent Sepsis Bundle".

OUTPUT JSON:
- riskLevel: SAFE, WARNING, CRITICAL.
- visualAnalysis: Analysis of image.
- vitalsAnalysis: Analysis of physio trends.
- environmentalContext: How environment/behavior affects the reading.
- reasoning: Deductive logic.
- recommendedIntervention: The single best action to take.
- confidenceScore: 0-100.
`;

export const analyzeHealthData = async (
  vitalLogs: string, 
  envData: string,
  behaviorData: string,
  imageBase64: string,
  imageMimeType: string = "image/jpeg"
): Promise<AnalysisResult> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing.");
  }

  const ai = new GoogleGenAI({ apiKey });

  const prompt = `
    Analyze this Digital Twin snapshot:
    
    [ENVIRONMENT]
    ${envData}

    [BEHAVIOR]
    ${behaviorData}

    [VITALS LOG WINDOW (Last 60s)]
    Time,HR,Temp,BP_Sys,BP_Dia,SpO2,RespRate
    ${vitalLogs}
    
    [VISUAL INPUT]
    The attached image is the real-time feed of the IV insertion site.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          { text: prompt },
          {
            inlineData: {
              mimeType: imageMimeType,
              data: imageBase64,
            },
          },
        ],
      },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            visualAnalysis: { type: Type.STRING },
            vitalsAnalysis: { type: Type.STRING },
            environmentalContext: { type: Type.STRING },
            riskLevel: { type: Type.STRING, enum: ["SAFE", "WARNING", "CRITICAL"] },
            reasoning: { type: Type.STRING },
            recommendedIntervention: { type: Type.STRING },
            confidenceScore: { type: Type.NUMBER },
          },
          required: ["visualAnalysis", "vitalsAnalysis", "riskLevel", "reasoning", "recommendedIntervention", "environmentalContext"],
        },
      },
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error("Empty response from AI");
    }

    const data = JSON.parse(resultText) as AnalysisResult;
    data.timestamp = new Date().toLocaleTimeString();
    
    // Fallback safety
    if (!Object.values(RiskLevel).includes(data.riskLevel as RiskLevel)) {
        data.riskLevel = RiskLevel.WARNING; 
    }

    return data;
  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    throw error;
  }
};