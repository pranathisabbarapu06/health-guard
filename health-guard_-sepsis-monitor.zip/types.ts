export interface VitalLog {
  time: string;
  heartRate: number;
  temperature: number;
  bpSystolic: number;
  bpDiastolic: number;
  spO2: number; // Added Oxygen Saturation
  respirationRate: number; // Added Respiration
  isNoise?: boolean;
}

export interface EnvironmentalData {
  roomTemp: number; // Fahrenheit
  humidity: number; // Percentage
  lightLevel: number; // Lux
  noiseLevel: number; // dB
}

export interface BehavioralData {
  activityIndex: number; // 0 (Sleep) to 100 (Agitated)
  posture: 'LYING' | 'SITTING' | 'MOVING';
  facialExpression?: string; // Derived from Camera
}

export enum RiskLevel {
  SAFE = 'SAFE',
  WARNING = 'WARNING',
  CRITICAL = 'CRITICAL'
}

export interface AnalysisResult {
  visualAnalysis: string;
  vitalsAnalysis: string;
  environmentalContext: string; // New: AI analysis of environment
  riskLevel: RiskLevel;
  reasoning: string;
  recommendedIntervention: string; // New: Closed loop suggestion
  confidenceScore: number;
  timestamp: string;
}

export type SimulationMode = 'NORMAL' | 'SEPSIS_ONSET' | 'FEVER_SPIKE' | 'HIGH_ACTIVITY';

export interface SystemState {
  fluidsAdministered: boolean;
  antipyreticsAdministered: boolean;
}