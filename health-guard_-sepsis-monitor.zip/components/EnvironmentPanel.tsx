import React from 'react';
import { EnvironmentalData, BehavioralData } from '../types';

interface EnvironmentPanelProps {
  envData: EnvironmentalData;
  behaviorData: BehavioralData;
}

export const EnvironmentPanel: React.FC<EnvironmentPanelProps> = ({ envData, behaviorData }) => {
  return (
    <div className="bg-slate-800 rounded-xl border border-slate-700 p-4 h-full flex flex-col gap-4 shadow-lg">
      <div className="flex items-center gap-2 border-b border-slate-700 pb-2">
        <svg className="w-4 h-4 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064" />
        </svg>
        <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Environment & Behavior</h3>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Room Temp */}
        <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700/50">
          <span className="text-[10px] text-slate-500 uppercase">Room Temp</span>
          <div className="flex items-end gap-1">
            <span className="text-xl font-mono text-slate-200">{envData.roomTemp.toFixed(1)}</span>
            <span className="text-xs text-slate-500 mb-1">°F</span>
          </div>
        </div>

        {/* Humidity */}
        <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700/50">
          <span className="text-[10px] text-slate-500 uppercase">Humidity</span>
          <div className="flex items-end gap-1">
            <span className="text-xl font-mono text-blue-300">{envData.humidity.toFixed(0)}</span>
            <span className="text-xs text-slate-500 mb-1">%</span>
          </div>
        </div>

        {/* Activity Level */}
        <div className="col-span-2 bg-slate-900/50 p-3 rounded-lg border border-slate-700/50">
           <div className="flex justify-between items-center mb-2">
             <span className="text-[10px] text-slate-500 uppercase">Patient Activity Index</span>
             <span className={`text-xs font-bold ${behaviorData.activityIndex > 50 ? 'text-orange-400' : 'text-emerald-400'}`}>
                {behaviorData.activityIndex > 80 ? 'AGITATED' : behaviorData.activityIndex > 20 ? 'ACTIVE' : 'RESTING'}
             </span>
           </div>
           <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
             <div 
               className={`h-full transition-all duration-500 ${behaviorData.activityIndex > 50 ? 'bg-orange-500' : 'bg-emerald-500'}`}
               style={{ width: `${behaviorData.activityIndex}%` }}
             ></div>
           </div>
        </div>
        
        {/* Posture */}
        <div className="col-span-2 flex items-center justify-between bg-slate-900/50 p-3 rounded-lg border border-slate-700/50">
            <span className="text-[10px] text-slate-500 uppercase">Detected Posture</span>
            <span className="font-mono text-sm text-purple-300">{behaviorData.posture}</span>
        </div>
      </div>
    </div>
  );
};