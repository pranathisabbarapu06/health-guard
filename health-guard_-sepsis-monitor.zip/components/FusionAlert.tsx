import React from 'react';
import { RiskLevel } from '../types';

interface FusionAlertProps {
  riskLevel: RiskLevel;
  reasoning?: string;
  visualAnalysis?: string;
  vitalsAnalysis?: string;
  timestamp?: string;
}

export const FusionAlert: React.FC<FusionAlertProps> = ({ 
  riskLevel, 
  reasoning, 
  visualAnalysis, 
  vitalsAnalysis,
  timestamp 
}) => {
  const getStyles = () => {
    switch (riskLevel) {
      case RiskLevel.CRITICAL:
        return {
          container: 'bg-red-950/30 border-red-500',
          title: 'text-red-500',
          bar: 'bg-red-500',
          glow: 'shadow-[0_0_30px_rgba(239,68,68,0.2)]'
        };
      case RiskLevel.WARNING:
        return {
          container: 'bg-amber-950/30 border-amber-500',
          title: 'text-amber-500',
          bar: 'bg-amber-500',
          glow: 'shadow-[0_0_30px_rgba(245,158,11,0.2)]'
        };
      case RiskLevel.SAFE:
      default:
        return {
          container: 'bg-emerald-950/30 border-emerald-500',
          title: 'text-emerald-500',
          bar: 'bg-emerald-500',
          glow: 'shadow-[0_0_30px_rgba(16,185,129,0.2)]'
        };
    }
  };

  const styles = getStyles();

  return (
    <div className={`relative rounded-xl border-l-4 ${styles.container} ${styles.glow} bg-slate-800 p-6 overflow-hidden transition-all duration-500`}>
      {/* Background Tech Pattern */}
      <div className="absolute top-0 right-0 p-4 opacity-10">
         <svg className={`w-32 h-32 ${styles.title}`} fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2L1 21h22L12 2zm0 3.99L19.53 19H4.47L12 5.99zM11 16h2v2h-2zm0-6h2v4h-2z"/>
         </svg>
      </div>

      <div className="relative z-10 flex flex-col md:flex-row gap-6">
        {/* Left: Big Status */}
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
             <div className={`w-3 h-3 rounded-full ${styles.bar} animate-pulse`}></div>
             <span className={`font-mono text-sm uppercase tracking-widest ${styles.title}`}>Adaptive Sensor Fusion</span>
             {timestamp && <span className="text-slate-500 text-xs font-mono ml-auto">{timestamp}</span>}
          </div>
          <h2 className={`text-4xl font-black tracking-tight mb-4 ${styles.title}`}>
            {riskLevel}
          </h2>
          <p className="text-slate-300 text-lg leading-relaxed font-light">
            {reasoning || "System Initializing... Calibrating digital twin model."}
          </p>
        </div>

        {/* Right: Technical Breakdown */}
        {(visualAnalysis || vitalsAnalysis) && (
          <div className="md:w-1/3 border-t md:border-t-0 md:border-l border-slate-700 md:pl-6 pt-4 md:pt-0 flex flex-col justify-center gap-4">
            <div>
              <span className="text-xs text-slate-500 uppercase tracking-widest font-bold block mb-1">Visual Cues</span>
              <p className="text-sm text-slate-300">{visualAnalysis || "Analyzing..."}</p>
            </div>
            <div>
              <span className="text-xs text-slate-500 uppercase tracking-widest font-bold block mb-1">Physio Trend</span>
              <p className="text-sm text-slate-300">{vitalsAnalysis || "Analyzing..."}</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};