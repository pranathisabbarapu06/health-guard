import React from 'react';
import { VitalLog, RiskLevel } from '../types';

interface DigitalTwinProps {
  vitals: VitalLog;
  riskLevel: RiskLevel;
}

export const DigitalTwin: React.FC<DigitalTwinProps> = ({ vitals, riskLevel }) => {
  // Determine colors based on stats
  const heartColor = vitals.heartRate > 100 ? '#ef4444' : '#10b981'; // Red if tachycardia
  const lungColor = vitals.spO2 < 95 ? '#f59e0b' : '#3b82f6'; // Orange if low O2
  const bodyColor = vitals.temperature > 100.4 ? 'rgba(239, 68, 68, 0.2)' : 'rgba(16, 185, 129, 0.1)';
  const strokeColor = riskLevel === RiskLevel.CRITICAL ? '#ef4444' : riskLevel === RiskLevel.WARNING ? '#f59e0b' : '#10b981';

  return (
    <div className="bg-slate-800 rounded-xl border border-slate-700 h-full flex flex-col relative overflow-hidden shadow-lg">
       <div className="absolute top-0 left-0 p-4 z-10">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
             <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
             Digital Twin Simulation
          </h3>
          <p className="text-[10px] text-slate-500 mt-1">REAL-TIME PHYSIO-MAPPING</p>
       </div>

       <div className="flex-1 flex items-center justify-center relative">
          {/* Grid Background */}
          <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-5"></div>
          <div className="absolute inset-0" style={{ 
              backgroundImage: 'radial-gradient(circle, #1e293b 1px, transparent 1px)', 
              backgroundSize: '20px 20px', 
              opacity: 0.5 
          }}></div>

          {/* Abstract Body SVG */}
          <svg viewBox="0 0 200 400" className="h-[90%] w-auto drop-shadow-[0_0_15px_rgba(0,0,0,0.5)]">
             <defs>
               <filter id="glow">
                 <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
                 <feMerge>
                   <feMergeNode in="coloredBlur"/>
                   <feMergeNode in="SourceGraphic"/>
                 </feMerge>
               </filter>
             </defs>

             {/* Body Silhouette */}
             <path 
               d="M100 20 C 130 20, 150 50, 160 80 C 170 120, 160 200, 160 200 L 170 350 L 140 380 L 130 250 L 100 250 L 70 250 L 60 380 L 30 350 L 40 200 C 40 200, 30 120, 40 80 C 50 50, 70 20, 100 20 Z" 
               fill={bodyColor}
               stroke={strokeColor}
               strokeWidth="2"
               className="transition-colors duration-1000"
             />

             {/* Brain / CNS */}
             <circle cx="100" cy="50" r="15" fill="none" stroke="#6366f1" strokeWidth="2" opacity="0.6">
                <animate attributeName="r" values="15;17;15" dur="3s" repeatCount="indefinite" />
             </circle>

             {/* Lungs */}
             <path d="M75 100 Q 60 140 85 160" fill="none" stroke={lungColor} strokeWidth="3" strokeLinecap="round" />
             <path d="M125 100 Q 140 140 115 160" fill="none" stroke={lungColor} strokeWidth="3" strokeLinecap="round" />

             {/* Heart */}
             <path 
               d="M100 130 L 90 120 A 5 5 0 0 1 100 115 A 5 5 0 0 1 110 120 L 100 130" 
               fill={heartColor} 
               filter="url(#glow)"
               transform-origin="100 125"
             >
               <animateTransform 
                  attributeName="transform" 
                  type="scale" 
                  values="1;1.2;1" 
                  dur={`${60 / vitals.heartRate}s`} 
                  repeatCount="indefinite" 
                />
             </path>

             {/* Vascular System (Lines) */}
             <path d="M100 130 L 100 250" stroke={strokeColor} strokeWidth="1" strokeDasharray="4 2" opacity="0.5" />
             <path d="M100 130 L 50 100" stroke={strokeColor} strokeWidth="1" strokeDasharray="4 2" opacity="0.5" />
             <path d="M100 130 L 150 100" stroke={strokeColor} strokeWidth="1" strokeDasharray="4 2" opacity="0.5" />
             
          </svg>
          
          {/* Floating Stats Nodes */}
          <div className="absolute top-[30%] left-[10%] bg-slate-900/80 backdrop-blur px-2 py-1 rounded border border-slate-700 text-[10px] text-slate-300">
             SpO2: {vitals.spO2.toFixed(0)}%
          </div>
          <div className="absolute top-[35%] right-[10%] bg-slate-900/80 backdrop-blur px-2 py-1 rounded border border-slate-700 text-[10px] text-slate-300">
             BP: {Math.round(vitals.bpSystolic)}/{Math.round(vitals.bpDiastolic)}
          </div>
       </div>
    </div>
  );
};