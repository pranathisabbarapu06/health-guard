import React, { useEffect, useRef, useState, forwardRef, useImperativeHandle } from 'react';

interface CameraMonitorProps {
  onSnapshot?: (base64: string) => void;
}

export interface CameraMonitorRef {
  getSnapshot: () => string | null;
}

export const CameraMonitor = forwardRef<CameraMonitorRef, CameraMonitorProps>((props, ref) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isSimulation, setIsSimulation] = useState(false);
  const [simulatedState, setSimulatedState] = useState<'HEALTHY' | 'REDNESS' | 'PUS'>('HEALTHY');

  // Simulation images (using placeholder services or colors for demo purposes)
  // In a real app these would be real assets. We will use colored placeholders with text.
  const getSimulationImage = (state: string) => {
      // We will draw these onto the canvas to create a "fake" camera feed snapshot
      return state;
  };

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setIsSimulation(false);
    } catch (err) {
      console.error("Camera access denied or missing", err);
      setIsSimulation(true); // Fallback
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  useImperativeHandle(ref, () => ({
    getSnapshot: () => {
      const canvas = canvasRef.current;
      const video = videoRef.current;

      if (!canvas) return null;
      const ctx = canvas.getContext('2d');
      if (!ctx) return null;

      canvas.width = 640;
      canvas.height = 480;

      if (isSimulation) {
        // Draw Simulation State
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw "Arm"
        ctx.fillStyle = '#e2e8f0'; 
        ctx.fillRect(200, 100, 240, 400); // Arm shape

        // Draw IV Site Condition
        if (simulatedState === 'HEALTHY') {
           ctx.fillStyle = '#d1d5db'; // Normal skin tone-ish
           ctx.beginPath();
           ctx.arc(320, 240, 30, 0, 2 * Math.PI);
           ctx.fill();
           ctx.fillStyle = '#22c55e';
           ctx.font = '30px Arial';
           ctx.fillText("SIMULATION: HEALTHY", 20, 50);
        } else if (simulatedState === 'REDNESS') {
           ctx.fillStyle = '#ef4444'; // Red
           ctx.beginPath();
           ctx.arc(320, 240, 40, 0, 2 * Math.PI);
           ctx.fill(); // Erythema
           ctx.fillStyle = '#ef4444';
           ctx.font = '30px Arial';
           ctx.fillText("SIMULATION: REDNESS", 20, 50);
        } else {
           ctx.fillStyle = '#ef4444'; // Red base
           ctx.beginPath();
           ctx.arc(320, 240, 45, 0, 2 * Math.PI);
           ctx.fill();
           ctx.fillStyle = '#fef08a'; // Pus yellow center
           ctx.beginPath();
           ctx.arc(320, 240, 15, 0, 2 * Math.PI);
           ctx.fill();
           ctx.fillStyle = '#ef4444';
           ctx.font = '30px Arial';
           ctx.fillText("SIMULATION: INFECTION", 20, 50);
        }

      } else {
        // Draw Live Video
        if (video && video.readyState === video.HAVE_ENOUGH_DATA) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        }
      }

      // Return base64 without prefix
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      return dataUrl.split(',')[1];
    }
  }));

  return (
    <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden flex flex-col h-full shadow-lg shadow-black/20">
      <div className="p-3 bg-slate-900 border-b border-slate-700 flex justify-between items-center">
        <div className="flex items-center gap-2">
           <div className={`w-2 h-2 rounded-full ${stream || isSimulation ? 'bg-red-500 animate-pulse' : 'bg-slate-600'}`}></div>
           <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">IV Site Monitor</span>
        </div>
        
        {/* Simulation Controls (Hidden in production, useful for demo) */}
        <div className="flex gap-1">
             <button 
               onClick={() => { setIsSimulation(true); setSimulatedState('HEALTHY'); }}
               className={`text-[10px] px-2 py-1 rounded ${simulatedState === 'HEALTHY' && isSimulation ? 'bg-emerald-900 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}
             >
               Normal
             </button>
             <button 
               onClick={() => { setIsSimulation(true); setSimulatedState('REDNESS'); }}
               className={`text-[10px] px-2 py-1 rounded ${simulatedState === 'REDNESS' && isSimulation ? 'bg-red-900 text-red-400' : 'bg-slate-800 text-slate-500'}`}
             >
               Redness
             </button>
             <button 
               onClick={() => { setIsSimulation(false); startCamera(); }}
               className={`text-[10px] px-2 py-1 rounded border border-slate-700 ${!isSimulation ? 'bg-blue-900 text-blue-400' : 'bg-slate-800 text-slate-500'}`}
             >
               Live Cam
             </button>
        </div>
      </div>
      
      <div className="relative flex-1 bg-black flex items-center justify-center overflow-hidden">
        {isSimulation ? (
            <div className="w-full h-full flex items-center justify-center bg-slate-900 relative">
                 <div className="text-center">
                    <div className="w-64 h-64 mx-auto mb-4 relative flex items-center justify-center bg-slate-800 rounded-full border-4 border-slate-700">
                        {simulatedState === 'HEALTHY' && <div className="w-48 h-48 bg-[#d4bbb1] rounded-full opacity-80"></div>}
                        {simulatedState === 'REDNESS' && <div className="w-48 h-48 bg-[#ff9999] rounded-full shadow-[0_0_30px_rgba(239,68,68,0.5)] border-4 border-red-400/30"></div>}
                    </div>
                    <p className="text-slate-500 font-mono text-xs uppercase animate-pulse">Running Simulation: {simulatedState}</p>
                 </div>
                 {/* Overlay Grid */}
                 <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10 pointer-events-none"></div>
            </div>
        ) : (
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            muted 
            className="w-full h-full object-cover"
          />
        )}
        
        {/* Targeting Reticle */}
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-30">
           <div className="w-48 h-48 border border-white/50 rounded-full"></div>
           <div className="absolute w-4 h-4 bg-white/50 rounded-full"></div>
           <div className="absolute top-4 bottom-4 w-px bg-white/20"></div>
           <div className="absolute left-4 right-4 h-px bg-white/20"></div>
        </div>

        {/* Hidden Canvas for Snapshots */}
        <canvas ref={canvasRef} className="hidden" />
      </div>
    </div>
  );
});

CameraMonitor.displayName = 'CameraMonitor';
