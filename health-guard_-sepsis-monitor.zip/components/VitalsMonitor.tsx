import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';
import { VitalLog } from '../types';

interface VitalsMonitorProps {
  data: VitalLog[];
}

export const VitalsMonitor: React.FC<VitalsMonitorProps> = ({ data }) => {
  // Get latest values for display
  const current = data[data.length - 1] || { heartRate: 0, temperature: 0, bpSystolic: 0, bpDiastolic: 0 };

  return (
    <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden flex flex-col h-full shadow-lg shadow-black/20">
      {/* Digital Readout Header */}
      <div className="grid grid-cols-3 divide-x divide-slate-700 bg-slate-900 border-b border-slate-700">
        <div className="p-4 flex flex-col items-center justify-center">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Heart Rate</span>
          <div className="flex items-baseline gap-1">
            <span className="text-3xl font-mono font-bold text-emerald-400 animate-pulse">{Math.round(current.heartRate)}</span>
            <span className="text-xs text-slate-500">BPM</span>
          </div>
        </div>
        <div className="p-4 flex flex-col items-center justify-center">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Body Temp</span>
          <div className="flex items-baseline gap-1">
            <span className={`text-3xl font-mono font-bold ${current.temperature > 99.5 ? 'text-red-400' : 'text-blue-400'}`}>
              {current.temperature.toFixed(1)}
            </span>
            <span className="text-xs text-slate-500">°F</span>
          </div>
        </div>
        <div className="p-4 flex flex-col items-center justify-center">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">Blood Pressure</span>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-mono font-bold text-purple-400">
              {Math.round(current.bpSystolic)}/{Math.round(current.bpDiastolic)}
            </span>
            <span className="text-xs text-slate-500">mmHg</span>
          </div>
        </div>
      </div>

      {/* Real-time Chart */}
      <div className="flex-1 min-h-[250px] bg-slate-800/50 p-4 relative">
        <div className="absolute top-2 left-4 z-10">
          <span className="text-xs font-mono text-emerald-500/50">LIVE STREAM // NOISE FILTER: ACTIVE</span>
        </div>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
            <XAxis hide={true} dataKey="time" />
            <YAxis 
              yAxisId="hr" 
              hide={true} 
              domain={[40, 200]} 
            />
            <YAxis 
              yAxisId="temp" 
              orientation="right" 
              domain={[94, 104]} 
              tick={{fill: '#64748b', fontSize: 10, fontFamily: 'monospace'}}
              tickCount={5}
            />
            
            {/* Heart Rate Line */}
            <Area 
              yAxisId="hr"
              type="monotone" 
              dataKey="heartRate" 
              stroke="#10b981" 
              strokeWidth={2} 
              fill="transparent" 
              isAnimationActive={false} // Disable animation for smoother streaming look
            />
            
            {/* Temperature Area */}
            <Area 
              yAxisId="temp"
              type="monotone" 
              dataKey="temperature" 
              stroke="#3b82f6" 
              strokeWidth={3} 
              fill="url(#colorTemp)" 
              isAnimationActive={false}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};