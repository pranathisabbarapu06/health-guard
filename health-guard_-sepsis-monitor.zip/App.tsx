import React, { useState, useEffect, useRef, useCallback } from 'react';
import { CameraMonitor, CameraMonitorRef } from './components/CameraMonitor';
import { VitalsMonitor } from './components/VitalsMonitor';
import { FusionAlert } from './components/FusionAlert';
import { DigitalTwin } from './components/DigitalTwin';
import { EnvironmentPanel } from './components/EnvironmentPanel';
import { analyzeHealthData } from './services/geminiService';
import { AnalysisResult, RiskLevel, VitalLog, SimulationMode, EnvironmentalData, BehavioralData, SystemState } from './types';

// Simulation Constants
const MAX_HISTORY = 60; // Keep last 60 ticks
const TICK_RATE_MS = 1000; // 1 second updates

function App() {
  // --- State ---
  const [vitalsHistory, setVitalsHistory] = useState<VitalLog[]>([]);
  const [envData, setEnvData] = useState<EnvironmentalData>({ roomTemp: 72, humidity: 45, lightLevel: 300, noiseLevel: 40 });
  const [behaviorData, setBehaviorData] = useState<BehavioralData>({ activityIndex: 10, posture: 'LYING' });
  
  const [simulationMode, setSimulationMode] = useState<SimulationMode>('NORMAL');
  const [systemState, setSystemState] = useState<SystemState>({ fluidsAdministered: false, antipyreticsAdministered: false });
  
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastAnalysis, setLastAnalysis] = useState<AnalysisResult | null>(null);
  
  // Refs for logic that doesn't need to trigger re-renders inside loops
  const cameraRef = useRef<CameraMonitorRef>(null);
  const vitalsRef = useRef<VitalLog[]>([]);
  
  // Initialize fake data
  useEffect(() => {
    const initialData: VitalLog[] = [];
    const now = new Date();
    for (let i = 0; i < 20; i++) {
      const time = new Date(now.getTime() - (20 - i) * 1000).toLocaleTimeString();
      initialData.push({
        time,
        heartRate: 70 + Math.random() * 5,
        temperature: 98.6 + Math.random() * 0.2,
        bpSystolic: 120,
        bpDiastolic: 80,
        spO2: 98,
        respirationRate: 16
      });
    }
    setVitalsHistory(initialData);
    vitalsRef.current = initialData;
  }, []);

  // --- Simulation Loop ---
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Update Environment & Behavior based on Mode
      setEnvData(prevEnv => {
         let newTemp = prevEnv.roomTemp;
         if (simulationMode === 'NORMAL') newTemp = 72 + Math.random();
         // Random fluctuations
         return {
           ...prevEnv,
           roomTemp: newTemp
         };
      });

      setBehaviorData(prevBeh => {
         let act = prevBeh.activityIndex;
         if (simulationMode === 'HIGH_ACTIVITY') {
            act = Math.min(100, act + 5);
         } else if (simulationMode === 'NORMAL') {
            act = Math.max(10, act - 2);
         }
         return {
           activityIndex: act,
           posture: act > 50 ? 'MOVING' : 'LYING'
         };
      });

      // 2. Update Vitals
      setVitalsHistory(prev => {
        const last = prev[prev.length - 1];
        const time = new Date().toLocaleTimeString();
        let newLog: VitalLog;

        // Base values
        let hr = last.heartRate;
        let temp = last.temperature;
        let sys = last.bpSystolic;
        let dia = last.bpDiastolic;
        let spO2 = last.spO2;

        // --- APPY SIMULATION PHYSICS ---
        
        // 1. Mode Effects
        if (simulationMode === 'SEPSIS_ONSET') {
          // Slow Creep: Temp rises, HR rises, BP drops
          if (!systemState.antipyreticsAdministered) temp += 0.05;
          if (!systemState.fluidsAdministered) {
             hr += 0.1;
             sys -= 0.1;
             dia -= 0.05;
          }
        } else if (simulationMode === 'HIGH_ACTIVITY') {
           hr += 0.5;
           if (hr > 110) hr = 110; // Cap
           sys += 0.2;
        } else {
          // Normal: Drift back to baseline
          if (temp > 98.6) temp -= 0.05;
          if (temp < 98.6) temp += 0.05;
          if (hr > 75) hr -= 0.5;
          if (hr < 70) hr += 0.5;
          if (sys < 120) sys += 0.5; // Recovery from hypotension if fluids given
        }

        // 2. Closed Loop Intervention Effects
        if (systemState.fluidsAdministered) {
            if (sys < 115) sys += 1.0; // Rapid BP recovery
            if (hr > 80) hr -= 0.5; // HR stabilizes
        }
        if (systemState.antipyreticsAdministered) {
            if (temp > 99.0) temp -= 0.1; // Rapid cooling
        }

        // 3. Add Natural Fluctuation
        temp += (Math.random() - 0.5) * 0.05;
        hr += (Math.random() - 0.5) * 2;
        spO2 = 98 + (Math.random() - 0.5) * 1;

        // 4. Add NOISE Artifacts (Random Spikes)
        const isNoise = Math.random() > 0.95; 
        if (isNoise) {
           if (Math.random() > 0.5) hr = 180; // HR Spike
        }

        newLog = {
          time,
          heartRate: hr,
          temperature: temp,
          bpSystolic: sys,
          bpDiastolic: dia,
          spO2,
          respirationRate: 16 + (hr - 70) / 10,
          isNoise
        };

        const newData = [...prev, newLog].slice(-MAX_HISTORY);
        vitalsRef.current = newData; // Update ref for analysis
        return newData;
      });
    }, TICK_RATE_MS);

    return () => clearInterval(interval);
  }, [simulationMode, systemState]);

  // --- Analysis Logic ---
  const runFusionAnalysis = useCallback(async () => {
    if (isAnalyzing) return;
    setIsAnalyzing(true);

    try {
      // 1. Get Snapshot
      const imageBase64 = cameraRef.current?.getSnapshot();
      if (!imageBase64) {
        throw new Error("Camera feed unavailable");
      }

      // 2. Get Data Strings
      const logs = vitalsRef.current.map(v => 
        `${v.time},${v.heartRate.toFixed(0)},${v.temperature.toFixed(1)},${v.bpSystolic.toFixed(0)},${v.bpDiastolic.toFixed(0)},${v.spO2.toFixed(0)},${v.respirationRate.toFixed(0)}`
      ).join('\n');

      const envString = `RoomTemp: ${envData.roomTemp.toFixed(1)}F, Humidity: ${envData.humidity}%`;
      const behString = `ActivityIndex: ${behaviorData.activityIndex}, Posture: ${behaviorData.posture}`;

      // 3. Call API
      const result = await analyzeHealthData(logs, envString, behString, imageBase64);
      setLastAnalysis(result);
    } catch (e) {
      console.error("Analysis Error", e);
    } finally {
      setIsAnalyzing(false);
    }
  }, [isAnalyzing, envData, behaviorData]);

  // Auto-scan loop
  useEffect(() => {
    const scanInterval = setInterval(() => {
        runFusionAnalysis();
    }, 8000); 
    return () => clearInterval(scanInterval);
  }, [runFusionAnalysis]);

  // --- Intervention Handlers ---
  const applyIntervention = (type: 'FLUIDS' | 'ANTIPYRETICS') => {
      if (type === 'FLUIDS') setSystemState(p => ({ ...p, fluidsAdministered: true }));
      if (type === 'ANTIPYRETICS') setSystemState(p => ({ ...p, antipyreticsAdministered: true }));
  };

  const resetSimulation = () => {
      setSimulationMode('NORMAL');
      setSystemState({ fluidsAdministered: false, antipyreticsAdministered: false });
  };


  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 pb-10 font-sans">
      {/* Top Bar */}
      <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
        <div className="max-w-[1600px] mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
             <div className="bg-emerald-500/10 p-2 rounded border border-emerald-500/20">
               <svg className="w-5 h-5 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
               </svg>
             </div>
             <div>
               <h1 className="text-lg font-bold text-slate-100 tracking-tight">HEALTH GUARD <span className="text-emerald-500">v2.0</span></h1>
               <div className="flex items-center gap-2">
                 <span className="relative flex h-2 w-2">
                   <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                   <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                 </span>
                 <span className="text-[10px] text-slate-500 font-mono uppercase tracking-widest">Bio-Adaptive Monitoring</span>
               </div>
             </div>
          </div>
          
          <div className="flex items-center gap-4">
             {/* Simulation Controls */}
             <div className="hidden md:flex bg-slate-800 p-1 rounded-lg border border-slate-700">
                <button onClick={resetSimulation} className={`px-3 py-1 text-xs font-bold rounded ${simulationMode === 'NORMAL' ? 'bg-slate-700 text-white' : 'text-slate-500'}`}>NORMAL</button>
                <button onClick={() => setSimulationMode('HIGH_ACTIVITY')} className={`px-3 py-1 text-xs font-bold rounded ${simulationMode === 'HIGH_ACTIVITY' ? 'bg-blue-900/50 text-blue-400' : 'text-slate-500'}`}>ACTIVITY</button>
                <button onClick={() => setSimulationMode('SEPSIS_ONSET')} className={`px-3 py-1 text-xs font-bold rounded ${simulationMode === 'SEPSIS_ONSET' ? 'bg-red-900/50 text-red-400' : 'text-slate-500'}`}>SEPSIS</button>
             </div>

             <button 
               onClick={runFusionAnalysis}
               disabled={isAnalyzing}
               className={`px-4 py-2 rounded-lg font-bold text-sm transition-all flex items-center gap-2 ${isAnalyzing ? 'bg-slate-800 text-slate-500' : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/50'}`}
             >
               {isAnalyzing ? 'FUSING DATA...' : 'SCAN NOW'}
             </button>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-4 py-6 space-y-6">
        
        {/* Top: Fused Status Alert with Closed Loop Recommendation */}
        <div className="animate-fade-in">
           <FusionAlert 
              riskLevel={lastAnalysis?.riskLevel || RiskLevel.SAFE} 
              reasoning={lastAnalysis?.reasoning}
              visualAnalysis={lastAnalysis?.visualAnalysis}
              vitalsAnalysis={lastAnalysis?.vitalsAnalysis}
              timestamp={lastAnalysis?.timestamp}
           />
           
           {/* CLOSED LOOP ACTION PANEL */}
           {lastAnalysis?.recommendedIntervention && (
              <div className="mt-4 bg-slate-900/80 border border-slate-700 rounded-lg p-4 flex flex-col md:flex-row items-center justify-between gap-4 animate-slide-up">
                  <div className="flex items-center gap-3">
                      <div className="bg-blue-500/10 p-2 rounded-full text-blue-400">
                         <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                      </div>
                      <div>
                          <span className="text-xs font-bold text-blue-500 uppercase tracking-widest">AI Recommendation</span>
                          <p className="text-lg text-slate-200 font-semibold">{lastAnalysis.recommendedIntervention}</p>
                      </div>
                  </div>
                  <div className="flex gap-2">
                     <button 
                        onClick={() => applyIntervention('FLUIDS')}
                        className={`px-4 py-2 rounded font-bold text-sm transition-colors ${systemState.fluidsAdministered ? 'bg-emerald-900/50 text-emerald-400 border border-emerald-500/50' : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-600'}`}
                     >
                        {systemState.fluidsAdministered ? '✓ FLUIDS ACTIVE' : 'Administer Fluids'}
                     </button>
                     <button 
                        onClick={() => applyIntervention('ANTIPYRETICS')}
                        className={`px-4 py-2 rounded font-bold text-sm transition-colors ${systemState.antipyreticsAdministered ? 'bg-emerald-900/50 text-emerald-400 border border-emerald-500/50' : 'bg-slate-800 hover:bg-slate-700 text-white border border-slate-600'}`}
                     >
                        {systemState.antipyreticsAdministered ? '✓ COOLING ACTIVE' : 'Start Cooling'}
                     </button>
                  </div>
              </div>
           )}
        </div>

        {/* Dashboard Grid - 3 Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[600px]">
          
          {/* Left: Vitals Graph (5 cols) */}
          <div className="lg:col-span-5 h-full flex flex-col gap-4">
             <VitalsMonitor data={vitalsHistory} />
          </div>

          {/* Center: Digital Twin (4 cols) */}
          <div className="lg:col-span-4 h-full">
             <DigitalTwin 
                vitals={vitalsHistory[vitalsHistory.length - 1] || {heartRate:0, temperature:0, bpSystolic:0, bpDiastolic:0, spO2:0}} 
                riskLevel={lastAnalysis?.riskLevel || RiskLevel.SAFE}
             />
          </div>

          {/* Right: Camera & Environment (3 cols) */}
          <div className="lg:col-span-3 h-full flex flex-col gap-4">
             <div className="h-[40%]">
                 <CameraMonitor ref={cameraRef} />
             </div>
             <div className="h-[60%]">
                 <EnvironmentPanel envData={envData} behaviorData={behaviorData} />
             </div>
          </div>
        </div>
        
      </main>
    </div>
  );
}

export default App;